from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'spicecraft_secret_2024'
DB = 'food_ordering.db'

# ─── DB Helpers ───────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript('''
        CREATE TABLE IF NOT EXISTS categories (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT DEFAULT '🍽️'
        );
        CREATE TABLE IF NOT EXISTS menu_items (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id  INTEGER,
            name         TEXT NOT NULL,
            description  TEXT,
            price        REAL NOT NULL,
            is_available INTEGER DEFAULT 1,
            FOREIGN KEY (category_id) REFERENCES categories(id)
        );
        CREATE TABLE IF NOT EXISTS orders (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name  TEXT NOT NULL,
            customer_phone TEXT,
            table_number   INTEGER DEFAULT 0,
            order_type     TEXT DEFAULT 'dine-in',
            status         TEXT DEFAULT 'pending',
            total_amount   REAL DEFAULT 0,
            created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS order_items (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id     INTEGER,
            menu_item_id INTEGER,
            quantity     INTEGER NOT NULL,
            unit_price   REAL NOT NULL,
            subtotal     REAL NOT NULL,
            FOREIGN KEY (order_id)     REFERENCES orders(id),
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
        );
        CREATE TABLE IF NOT EXISTS cart_items (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id   TEXT NOT NULL,
            menu_item_id INTEGER NOT NULL,
            quantity     INTEGER DEFAULT 1,
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
        );
    ''')
    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        cats = [('Starters','🥗'),('Main Course','🍛'),('Breads','🫓'),('Beverages','🥤'),('Desserts','🍮')]
        c.executemany("INSERT INTO categories(name,icon) VALUES(?,?)", cats)
        items = [
            (1,'Paneer Tikka','Grilled cottage cheese with spices',180),
            (1,'Veg Spring Rolls','Crispy rolls with veggie filling',120),
            (1,'Chicken Manchurian','Fried chicken in spicy sauce',200),
            (1,'Samosa (2 pcs)','Classic Indian fried pastry',60),
            (2,'Dal Makhani','Creamy black lentils slow cooked',180),
            (2,'Butter Chicken','Tender chicken in tomato butter gravy',280),
            (2,'Paneer Butter Masala','Cottage cheese in rich tomato gravy',240),
            (2,'Veg Biryani','Aromatic basmati rice with veggies',200),
            (2,'Chicken Biryani','Spiced basmati rice with chicken',300),
            (2,'Palak Paneer','Cottage cheese in spinach gravy',220),
            (3,'Butter Naan','Soft leavened flatbread with butter',40),
            (3,'Garlic Naan','Naan topped with garlic and herbs',50),
            (3,'Tandoori Roti','Whole wheat bread from tandoor',30),
            (3,'Paratha','Layered wheat flatbread',45),
            (4,'Mango Lassi','Yogurt-based mango drink',100),
            (4,'Masala Chai','Spiced Indian milk tea',40),
            (4,'Cold Coffee','Chilled coffee with cream',120),
            (4,'Fresh Lime Soda','Refreshing lime with soda',80),
            (5,'Gulab Jamun','Fried milk solids in sugar syrup',80),
            (5,'Rasgulla','Soft cottage cheese balls in syrup',80),
            (5,'Ice Cream (2 scoops)','Vanilla / Chocolate / Strawberry',100),
            (5,'Kheer','Creamy rice pudding with dry fruits',90),
        ]
        c.executemany("INSERT INTO menu_items(category_id,name,description,price) VALUES(?,?,?,?)", items)
    conn.commit()
    conn.close()

def get_session_id():
    if 'sid' not in session:
        import uuid
        session['sid'] = str(uuid.uuid4())
    return session['sid']

def get_cart(sid):
    conn = get_db()
    rows = conn.execute('''
        SELECT ci.id, ci.quantity, m.id as item_id, m.name, m.price,
               (ci.quantity * m.price) as subtotal
        FROM cart_items ci
        JOIN menu_items m ON ci.menu_item_id = m.id
        WHERE ci.session_id = ?
    ''', (sid,)).fetchall()
    conn.close()
    return rows

def cart_total(cart):
    return sum(r['subtotal'] for r in cart)

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    conn = get_db()
    cats = conn.execute("SELECT * FROM categories").fetchall()
    conn.close()
    sid = get_session_id()
    cart = get_cart(sid)
    return render_template('index.html', categories=cats, cart_count=sum(r['quantity'] for r in cart))

@app.route('/menu')
def menu():
    sid = get_session_id()
    conn = get_db()
    cats = conn.execute("SELECT * FROM categories").fetchall()
    sel_cat = request.args.get('cat', 'all')
    search  = request.args.get('q', '').strip()
    query = '''SELECT m.*, c.name as cat_name, c.icon as cat_icon
               FROM menu_items m JOIN categories c ON m.category_id = c.id
               WHERE m.is_available = 1'''
    params = []
    if sel_cat != 'all':
        query += ' AND c.name = ?'
        params.append(sel_cat)
    if search:
        query += ' AND m.name LIKE ?'
        params.append(f'%{search}%')
    items = conn.execute(query, params).fetchall()
    conn.close()
    cart = get_cart(sid)
    cart_ids = {r['item_id']: r['quantity'] for r in cart}
    return render_template('menu.html', categories=cats, items=items,
                           sel_cat=sel_cat, search=search,
                           cart_count=sum(r['quantity'] for r in cart),
                           cart_ids=cart_ids)

@app.route('/cart/add/<int:item_id>', methods=['POST'])
def add_to_cart(item_id):
    sid = get_session_id()
    conn = get_db()
    existing = conn.execute(
        "SELECT id, quantity FROM cart_items WHERE session_id=? AND menu_item_id=?",
        (sid, item_id)).fetchone()
    if existing:
        conn.execute("UPDATE cart_items SET quantity=? WHERE id=?",
                     (existing['quantity'] + 1, existing['id']))
    else:
        conn.execute("INSERT INTO cart_items(session_id, menu_item_id, quantity) VALUES(?,?,1)",
                     (sid, item_id))
    conn.commit()
    conn.close()
    # Return to wherever the form was submitted from
    ref = request.form.get('ref', 'menu')
    cat = request.form.get('cat', 'all')
    q   = request.form.get('q', '')
    if ref == 'index':
        return redirect(url_for('index'))
    return redirect(url_for('menu', cat=cat, q=q))

@app.route('/cart/remove/<int:cart_id>', methods=['POST'])
def remove_from_cart(cart_id):
    sid = get_session_id()
    conn = get_db()
    conn.execute("DELETE FROM cart_items WHERE id=? AND session_id=?", (cart_id, sid))
    conn.commit()
    conn.close()
    return redirect(url_for('cart'))

@app.route('/cart/update/<int:cart_id>', methods=['POST'])
def update_cart(cart_id):
    sid = get_session_id()
    qty = int(request.form.get('quantity', 1))
    conn = get_db()
    if qty <= 0:
        conn.execute("DELETE FROM cart_items WHERE id=? AND session_id=?", (cart_id, sid))
    else:
        conn.execute("UPDATE cart_items SET quantity=? WHERE id=? AND session_id=?",
                     (qty, cart_id, sid))
    conn.commit()
    conn.close()
    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    sid = get_session_id()
    cart = get_cart(sid)
    subtotal = cart_total(cart)
    gst = round(subtotal * 0.05, 2)
    grand = round(subtotal + gst, 2)
    return render_template('cart.html', cart=cart, subtotal=subtotal,
                           gst=gst, grand=grand,
                           cart_count=sum(r['quantity'] for r in cart))

@app.route('/checkout', methods=['POST'])
def checkout():
    sid = get_session_id()
    cart = get_cart(sid)
    if not cart:
        return redirect(url_for('cart'))

    name   = request.form.get('customer_name', 'Guest').strip() or 'Guest'
    phone  = request.form.get('customer_phone', '').strip()
    table  = int(request.form.get('table_number', 0) or 0)
    otype  = request.form.get('order_type', 'dine-in')
    subtotal = cart_total(cart)

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO orders(customer_name,customer_phone,table_number,order_type,total_amount) VALUES(?,?,?,?,?)",
        (name, phone, table, otype, subtotal))
    order_id = cur.lastrowid
    for item in cart:
        cur.execute(
            "INSERT INTO order_items(order_id,menu_item_id,quantity,unit_price,subtotal) VALUES(?,?,?,?,?)",
            (order_id, item['item_id'], item['quantity'], item['price'], item['subtotal']))
    # Clear cart
    conn.execute("DELETE FROM cart_items WHERE session_id=?", (sid,))
    conn.commit()
    conn.close()
    return redirect(url_for('bill', order_id=order_id))

@app.route('/bill/<int:order_id>')
def bill(order_id):
    conn = get_db()
    order = conn.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    if not order:
        return "Order not found", 404
    items = conn.execute('''
        SELECT oi.*, m.name as item_name
        FROM order_items oi JOIN menu_items m ON oi.menu_item_id = m.id
        WHERE oi.order_id = ?''', (order_id,)).fetchall()
    conn.close()
    gst   = round(order['total_amount'] * 0.05, 2)
    grand = round(order['total_amount'] + gst, 2)
    sid = get_session_id()
    cart = get_cart(sid)
    return render_template('bill.html', order=order, items=items,
                           gst=gst, grand=grand,
                           cart_count=sum(r['quantity'] for r in cart))

@app.route('/admin')
def admin():
    conn = get_db()
    orders = conn.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT 100").fetchall()
    total_rev    = conn.execute("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE status!='cancelled'").fetchone()[0]
    total_orders = conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    pending      = conn.execute("SELECT COUNT(*) FROM orders WHERE status='pending'").fetchone()[0]
    completed    = conn.execute("SELECT COUNT(*) FROM orders WHERE status='completed'").fetchone()[0]
    conn.close()
    sid = get_session_id()
    cart = get_cart(sid)
    return render_template('admin.html', orders=orders,
                           total_rev=total_rev, total_orders=total_orders,
                           pending=pending, completed=completed,
                           cart_count=sum(r['quantity'] for r in cart))

@app.route('/admin/status/<int:order_id>', methods=['POST'])
def update_status(order_id):
    status = request.form.get('status')
    conn = get_db()
    conn.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    conn.commit()
    conn.close()
    return redirect(url_for('admin'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
