from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import uuid
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'suraksha_shield_2024_secret'
DB = 'suraksha.db'

# ─── DB Setup ────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name     TEXT NOT NULL,
            phone         TEXT NOT NULL UNIQUE,
            email         TEXT,
            address       TEXT,
            city          TEXT,
            state         TEXT,
            aadhaar_last4 TEXT,
            password      TEXT NOT NULL,
            role          TEXT DEFAULT 'user',
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS emergency_contacts (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            name       TEXT NOT NULL,
            phone      TEXT NOT NULL,
            relation   TEXT,
            is_primary INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS incidents (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id       INTEGER,
            victim_name   TEXT NOT NULL,
            victim_age    INTEGER,
            victim_gender TEXT DEFAULT 'female',
            category      TEXT NOT NULL,
            description   TEXT NOT NULL,
            location      TEXT NOT NULL,
            city          TEXT,
            state         TEXT,
            date_of_incident TEXT,
            evidence_desc TEXT,
            accused_name  TEXT,
            accused_desc  TEXT,
            status        TEXT DEFAULT 'pending',
            priority      TEXT DEFAULT 'normal',
            ipc_section   TEXT,
            assigned_to   TEXT,
            remarks       TEXT,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS sos_alerts (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER,
            name       TEXT NOT NULL,
            phone      TEXT NOT NULL,
            location   TEXT NOT NULL,
            message    TEXT,
            status     TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS awareness_articles (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            title      TEXT NOT NULL,
            category   TEXT NOT NULL,
            content    TEXT NOT NULL,
            law_ref    TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS admin_users (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            name     TEXT NOT NULL
        );
    ''')

    # Seed admin
    c.execute("SELECT COUNT(*) FROM admin_users")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO admin_users(username,password,name) VALUES(?,?,?)",
                  ('admin', 'admin123', 'Super Admin'))

    # Seed awareness articles
    c.execute("SELECT COUNT(*) FROM awareness_articles")
    if c.fetchone()[0] == 0:
        articles = [
            ('Protection of Women from Domestic Violence Act, 2005',
             'Legal Rights',
             'The Protection of Women from Domestic Violence Act 2005 (PWDVA) protects women from physical, emotional, sexual, and economic abuse within the home. Key provisions:\n\n• Right to reside in the shared household even if she has no ownership rights\n• Right to protection orders, residence orders, monetary relief, custody orders and compensation orders\n• Magistrate can pass orders within 3 days of application\n• Violation of protection order is a cognizable and non-bailable offence\n• Every state government must appoint Protection Officers\n• NGOs can be notified as Service Providers\n\nTo file complaint: Visit nearest Magistrate Court, Women Police Station, or call 181 (Women Helpline).',
             'PWDVA 2005'),

            ('POCSO Act 2012 – Protection of Children from Sexual Offences',
             'Child Protection',
             'The Protection of Children from Sexual Offences (POCSO) Act 2012 protects children below 18 years from sexual abuse and exploitation:\n\n• Defines penetrative sexual assault, aggravated sexual assault, sexual harassment and pornography involving children\n• Mandatory reporting: Any person who has knowledge of sexual offence against child MUST report to Police or SJPU\n• Failure to report is a punishable offence (Section 21)\n• Child-friendly procedures: No child to be detained in police station at night, no child to be separated from guardian\n• Special Courts for speedy trial\n• Identity of child victim must NOT be disclosed\n• Punishment: Minimum 7 years rigorous imprisonment, extendable to life\n• Childline: 1098',
             'POCSO Act 2012'),

            ('IPC Sections for Women Safety',
             'Legal Rights',
             'Important Indian Penal Code sections protecting women:\n\n• Section 304B – Dowry Death (7 years to life imprisonment)\n• Section 354 – Assault on woman with intent to outrage modesty (1-5 years)\n• Section 354A – Sexual harassment (1-3 years)\n• Section 354B – Disrobing a woman (3-7 years)\n• Section 354C – Voyeurism (1-3 years, repeat: 3-7 years)\n• Section 354D – Stalking (1-3 years, repeat: 3-5 years)\n• Section 376 – Rape (minimum 10 years, life, or death in cases of repeat offenders/minor victims)\n• Section 498A – Cruelty by husband or relatives (3 years + fine)\n• Section 509 – Word/gesture insulting modesty of woman (3 years)\n\nFIR filing is FREE and mandatory for cognizable offences. Police CANNOT refuse to register FIR.',
             'IPC Sections'),

            ('Child Labour (Prohibition & Regulation) Amendment Act 2016',
             'Child Protection',
             'The Child Labour Amendment Act 2016 strengthens child protection:\n\n• Complete prohibition of employment of children below 14 years in all occupations\n• Children aged 14-18 prohibited from hazardous occupations\n• Punishment: Imprisonment of 6 months to 2 years OR fine of Rs. 20,000–50,000\n• Repeat offenders: Imprisonment of 1-3 years (mandatory)\n• Government to rehabilitate rescued children\n• Childline 1098 for reporting child labour\n• District Magistrate to be nodal authority for enforcement\n\nNote: Child can work in family enterprise or as artist, but not affecting education.',
             'Child Labour Act 2016'),

            ('Cyber Safety for Women and Children',
             'Cyber Safety',
             'Legal protections against cyber crimes:\n\n• IT Act Section 67 – Publishing obscene material online (5 years imprisonment)\n• IT Act Section 67A – Sexually explicit content (7 years imprisonment)\n• IT Act Section 67B – Child pornography (5-7 years + fine)\n• IPC 354D – Online stalking is a criminal offence\n• IPC 499/500 – Online defamation (2 years imprisonment)\n\nSteps if you are cyberbullied:\n1. Do NOT delete evidence – take screenshots\n2. Block the offender\n3. Report to cybercrime.gov.in or call 1930\n4. File complaint at nearest police station\n5. National Cyber Crime Reporting Portal: cybercrime.gov.in\n\nNational Cyber Crime Helpline: 1930',
             'IT Act & IPC'),

            ('Prohibition of Child Marriage Act 2006',
             'Child Protection',
             'The Prohibition of Child Marriage Act 2006 (PCMA):\n\n• Minimum marriage age: Girls – 18 years, Boys – 21 years\n• Child marriage is voidable at the option of the contracting party who was a child\n• Child Marriage Prohibition Officers (CMPO) appointed in every district\n• Imprisonment up to 2 years or fine up to Rs. 1 lakh for abettors\n• Parents/guardians conducting/permitting child marriage: punishable\n• Any person/organisation can file complaint\n\nNote: Child Marriage Restraint Bill 2021 proposes to raise minimum age for girls to 21 years.\n\nReport child marriage: 1098 (Childline) or nearest police station',
             'PCMA 2006'),
        ]
        c.executemany(
            "INSERT INTO awareness_articles(title,category,content,law_ref) VALUES(?,?,?,?)",
            articles
        )

    conn.commit()
    conn.close()

# ─── Helper ───────────────────────────────────────────────────────────────────

def get_session_user():
    return session.get('user_id'), session.get('user_name'), session.get('role')

def get_admin():
    return session.get('admin_id'), session.get('admin_name')

# ─── Public Routes ────────────────────────────────────────────────────────────

@app.route('/')
def index():
    uid, uname, role = get_session_user()
    conn = get_db()
    total_incidents = conn.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
    total_sos       = conn.execute("SELECT COUNT(*) FROM sos_alerts WHERE status='active'").fetchone()[0]
    articles        = conn.execute("SELECT id,title,category FROM awareness_articles ORDER BY id DESC LIMIT 4").fetchall()
    conn.close()
    return render_template('index.html', user_name=uname, total_incidents=total_incidents,
                           total_sos=total_sos, articles=articles)

@app.route('/emergency')
def emergency():
    uid, uname, role = get_session_user()
    return render_template('emergency.html', user_name=uname)

@app.route('/sos', methods=['GET','POST'])
def sos():
    uid, uname, role = get_session_user()
    msg = None
    if request.method == 'POST':
        name     = request.form.get('name','').strip()
        phone    = request.form.get('phone','').strip()
        location = request.form.get('location','').strip()
        message  = request.form.get('message','').strip()
        if name and phone and location:
            conn = get_db()
            conn.execute(
                "INSERT INTO sos_alerts(user_id,name,phone,location,message) VALUES(?,?,?,?,?)",
                (uid, name, phone, location, message))
            conn.commit()
            conn.close()
            msg = 'success'
        else:
            msg = 'error'
    return render_template('sos.html', user_name=uname, msg=msg)

@app.route('/report', methods=['GET','POST'])
def report():
    uid, uname, role = get_session_user()
    msg = None
    if request.method == 'POST':
        data = {
            'user_id':        uid,
            'victim_name':    request.form.get('victim_name','').strip(),
            'victim_age':     request.form.get('victim_age') or None,
            'victim_gender':  request.form.get('victim_gender','female'),
            'category':       request.form.get('category','').strip(),
            'description':    request.form.get('description','').strip(),
            'location':       request.form.get('location','').strip(),
            'city':           request.form.get('city','').strip(),
            'state':          request.form.get('state','').strip(),
            'date_of_incident': request.form.get('date_of_incident','').strip(),
            'evidence_desc':  request.form.get('evidence_desc','').strip(),
            'accused_name':   request.form.get('accused_name','').strip(),
            'accused_desc':   request.form.get('accused_desc','').strip(),
        }
        # Auto-assign IPC section
        ipc_map = {
            'Domestic Violence':    'IPC 498A, PWDVA 2005',
            'Sexual Harassment':    'IPC 354A, 509',
            'Rape / Sexual Assault':'IPC 376, 376A-D',
            'Stalking / Cyberbullying': 'IPC 354D, IT Act 67',
            'Child Sexual Abuse':   'POCSO Act 2012, IPC 376AB',
            'Child Labour':         'Child Labour Act 2016',
            'Child Marriage':       'PCMA 2006',
            'Acid Attack':          'IPC 326A, 326B',
            'Dowry Harassment':     'IPC 304B, 498A',
            'Human Trafficking':    'IPC 370, 370A',
            'Other':                'IPC 354',
        }
        data['ipc_section'] = ipc_map.get(data['category'], 'IPC 354')
        if data['victim_name'] and data['category'] and data['description'] and data['location']:
            conn = get_db()
            conn.execute('''INSERT INTO incidents
                (user_id,victim_name,victim_age,victim_gender,category,description,
                 location,city,state,date_of_incident,evidence_desc,accused_name,
                 accused_desc,ipc_section)
                VALUES(:user_id,:victim_name,:victim_age,:victim_gender,:category,:description,
                       :location,:city,:state,:date_of_incident,:evidence_desc,:accused_name,
                       :accused_desc,:ipc_section)''', data)
            conn.commit()
            conn.close()
            msg = 'success'
        else:
            msg = 'error'
    return render_template('report.html', user_name=uname, msg=msg)

@app.route('/awareness')
def awareness():
    uid, uname, role = get_session_user()
    cat  = request.args.get('cat','all')
    conn = get_db()
    if cat == 'all':
        articles = conn.execute("SELECT * FROM awareness_articles ORDER BY id DESC").fetchall()
    else:
        articles = conn.execute("SELECT * FROM awareness_articles WHERE category=? ORDER BY id DESC", (cat,)).fetchall()
    cats = conn.execute("SELECT DISTINCT category FROM awareness_articles").fetchall()
    conn.close()
    return render_template('awareness.html', articles=articles, cats=cats, sel_cat=cat, user_name=uname)

@app.route('/awareness/<int:article_id>')
def article_detail(article_id):
    uid, uname, role = get_session_user()
    conn = get_db()
    article = conn.execute("SELECT * FROM awareness_articles WHERE id=?", (article_id,)).fetchone()
    conn.close()
    if not article:
        return redirect(url_for('awareness'))
    return render_template('article_detail.html', article=article, user_name=uname)

@app.route('/track', methods=['GET','POST'])
def track():
    uid, uname, role = get_session_user()
    result = None
    if request.method == 'POST':
        ref = request.form.get('ref_id','').strip()
        phone = request.form.get('phone','').strip()
        conn = get_db()
        if ref:
            result = conn.execute("SELECT * FROM incidents WHERE id=?", (ref,)).fetchone()
        elif phone:
            result = conn.execute("SELECT * FROM incidents WHERE victim_name LIKE ? ORDER BY id DESC LIMIT 1", (f'%{phone}%',)).fetchone()
        conn.close()
    return render_template('track.html', user_name=uname, result=result)

# ─── Register / Login ─────────────────────────────────────────────────────────

@app.route('/register', methods=['GET','POST'])
def register():
    msg = None
    if request.method == 'POST':
        name  = request.form.get('full_name','').strip()
        phone = request.form.get('phone','').strip()
        email = request.form.get('email','').strip()
        pwd   = request.form.get('password','').strip()
        city  = request.form.get('city','').strip()
        state = request.form.get('state','').strip()
        if name and phone and pwd:
            try:
                conn = get_db()
                conn.execute(
                    "INSERT INTO users(full_name,phone,email,city,state,password) VALUES(?,?,?,?,?,?)",
                    (name, phone, email, city, state, pwd))
                conn.commit()
                conn.close()
                msg = 'success'
            except sqlite3.IntegrityError:
                msg = 'exists'
        else:
            msg = 'error'
    return render_template('register.html', msg=msg)

@app.route('/login', methods=['GET','POST'])
def login():
    msg = None
    if request.method == 'POST':
        phone = request.form.get('phone','').strip()
        pwd   = request.form.get('password','').strip()
        conn  = get_db()
        user  = conn.execute("SELECT * FROM users WHERE phone=? AND password=?", (phone, pwd)).fetchone()
        conn.close()
        if user:
            session['user_id']   = user['id']
            session['user_name'] = user['full_name']
            session['role']      = user['role']
            return redirect(url_for('index'))
        else:
            msg = 'invalid'
    return render_template('login.html', msg=msg)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ─── Admin Routes ─────────────────────────────────────────────────────────────

@app.route('/admin/login', methods=['GET','POST'])
def admin_login():
    msg = None
    if request.method == 'POST':
        uname = request.form.get('username','').strip()
        pwd   = request.form.get('password','').strip()
        conn  = get_db()
        admin = conn.execute("SELECT * FROM admin_users WHERE username=? AND password=?", (uname, pwd)).fetchone()
        conn.close()
        if admin:
            session['admin_id']   = admin['id']
            session['admin_name'] = admin['name']
            return redirect(url_for('admin_dashboard'))
        else:
            msg = 'invalid'
    return render_template('admin_login.html', msg=msg)

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_id', None)
    session.pop('admin_name', None)
    return redirect(url_for('admin_login'))

@app.route('/admin')
def admin_dashboard():
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    conn = get_db()
    total_incidents = conn.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
    pending         = conn.execute("SELECT COUNT(*) FROM incidents WHERE status='pending'").fetchone()[0]
    resolved        = conn.execute("SELECT COUNT(*) FROM incidents WHERE status='resolved'").fetchone()[0]
    total_sos       = conn.execute("SELECT COUNT(*) FROM sos_alerts").fetchone()[0]
    active_sos      = conn.execute("SELECT COUNT(*) FROM sos_alerts WHERE status='active'").fetchone()[0]
    total_users     = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    recent_incidents= conn.execute("SELECT * FROM incidents ORDER BY created_at DESC LIMIT 10").fetchall()
    recent_sos      = conn.execute("SELECT * FROM sos_alerts ORDER BY created_at DESC LIMIT 5").fetchall()
    conn.close()
    return render_template('admin_dashboard.html', admin_name=aname,
                           total_incidents=total_incidents, pending=pending,
                           resolved=resolved, total_sos=total_sos,
                           active_sos=active_sos, total_users=total_users,
                           recent_incidents=recent_incidents, recent_sos=recent_sos)

@app.route('/admin/incidents')
def admin_incidents():
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    status_f  = request.args.get('status','all')
    cat_f     = request.args.get('cat','all')
    conn = get_db()
    query  = "SELECT * FROM incidents WHERE 1=1"
    params = []
    if status_f != 'all':
        query += " AND status=?"; params.append(status_f)
    if cat_f != 'all':
        query += " AND category=?"; params.append(cat_f)
    query += " ORDER BY created_at DESC"
    incidents = conn.execute(query, params).fetchall()
    cats = conn.execute("SELECT DISTINCT category FROM incidents").fetchall()
    conn.close()
    return render_template('admin_incidents.html', admin_name=aname,
                           incidents=incidents, cats=cats,
                           status_f=status_f, cat_f=cat_f)

@app.route('/admin/incidents/<int:inc_id>', methods=['GET','POST'])
def admin_incident_detail(inc_id):
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    conn = get_db()
    if request.method == 'POST':
        status    = request.form.get('status')
        priority  = request.form.get('priority')
        assigned  = request.form.get('assigned_to','').strip()
        remarks   = request.form.get('remarks','').strip()
        conn.execute("UPDATE incidents SET status=?,priority=?,assigned_to=?,remarks=? WHERE id=?",
                     (status, priority, assigned, remarks, inc_id))
        conn.commit()
    incident = conn.execute("SELECT * FROM incidents WHERE id=?", (inc_id,)).fetchone()
    conn.close()
    return render_template('admin_incident_detail.html', admin_name=aname, incident=incident)

@app.route('/admin/sos')
def admin_sos():
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    conn = get_db()
    alerts = conn.execute("SELECT * FROM sos_alerts ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template('admin_sos.html', admin_name=aname, alerts=alerts)

@app.route('/admin/sos/resolve/<int:sos_id>', methods=['POST'])
def resolve_sos(sos_id):
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    conn = get_db()
    conn.execute("UPDATE sos_alerts SET status='resolved' WHERE id=?", (sos_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_sos'))

@app.route('/admin/users')
def admin_users():
    aid, aname = get_admin()
    if not aid:
        return redirect(url_for('admin_login'))
    conn = get_db()
    users = conn.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template('admin_users.html', admin_name=aname, users=users)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
