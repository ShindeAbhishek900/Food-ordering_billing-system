# 🛡️ Suraksha Shield — Women Safety & Child Protection System
## Pure HTML + CSS Frontend | Python Flask Backend | SQLite Database
## ⚠️ Zero JavaScript Used

---

## 📁 Project Structure

```
women_safety/
├── app.py                         ← Flask backend (all routes + SQLite)
├── requirements.txt               ← pip install flask
├── suraksha.db                    ← SQLite DB (auto-created on first run)
│
├── templates/
│   ├── base.html                  ← Navbar + ticker + footer layout
│   ├── index.html                 ← Home page
│   ├── emergency.html             ← All emergency numbers directory
│   ├── sos.html                   ← SOS alert form
│   ├── report.html                ← Report incident form
│   ├── awareness.html             ← Know Your Rights list
│   ├── article_detail.html        ← Single article view
│   ├── track.html                 ← Track case by ID
│   ├── register.html              ← User registration
│   ├── login.html                 ← User login
│   ├── admin_base.html            ← Admin layout
│   ├── admin_login.html           ← Admin login
│   ├── admin_dashboard.html       ← Admin dashboard
│   ├── admin_incidents.html       ← All incidents list
│   ├── admin_incident_detail.html ← Update individual case
│   ├── admin_sos.html             ← SOS alerts management
│   └── admin_users.html           ← Registered users list
│
└── static/
    └── css/
        └── style.css              ← Complete styles (no JS)
```

---

## ⚙️ Setup in PyCharm

### Step 1 — Install Flask
Open Terminal in PyCharm:
```
pip install flask
```

### Step 2 — Run the App
```
python app.py
```

### Step 3 — Open in Browser
```
http://127.0.0.1:5000
```

### Admin Panel
```
http://127.0.0.1:5000/admin
Username: admin
Password: admin123
```

---

## 🌐 Pages & URLs

| URL                        | Page                          |
|----------------------------|-------------------------------|
| `/`                        | Home                          |
| `/emergency`               | Emergency Numbers Directory   |
| `/sos`                     | Send SOS Alert                |
| `/report`                  | Report Incident Form          |
| `/awareness`               | Know Your Rights              |
| `/awareness/<id>`          | Article Detail                |
| `/track`                   | Track Case Status             |
| `/register`                | User Registration             |
| `/login`                   | User Login                    |
| `/admin`                   | Admin Dashboard               |
| `/admin/incidents`         | All Incidents                 |
| `/admin/incidents/<id>`    | Case Detail + Update          |
| `/admin/sos`               | SOS Alerts                    |
| `/admin/users`             | Registered Users              |

---

## 🗃️ SQLite Tables

| Table                  | Purpose                                      |
|------------------------|----------------------------------------------|
| `users`                | Registered users (victims/reporters)         |
| `emergency_contacts`   | Personal emergency contacts per user         |
| `incidents`            | Reported incidents with IPC section mapping  |
| `sos_alerts`           | SOS distress alerts                          |
| `awareness_articles`   | Legal rights articles seeded from Indian laws|
| `admin_users`          | Admin panel access                           |

---

## 🇮🇳 Indian Laws Covered

| Law                            | Section/Act             |
|-------------------------------|-------------------------|
| Domestic Violence              | PWDVA 2005, IPC 498A    |
| Sexual Harassment              | IPC 354A, 354B, 354C    |
| Rape / Sexual Assault          | IPC 376, 376A–D         |
| Stalking                       | IPC 354D                |
| Child Sexual Abuse             | POCSO Act 2012          |
| Child Labour                   | Child Labour Act 2016   |
| Child Marriage                 | PCMA 2006               |
| Acid Attack                    | IPC 326A, 326B          |
| Dowry                          | IPC 304B, 498A          |
| Human Trafficking              | IPC 370, 370A           |
| Cybercrime                     | IT Act 67, 67A, 67B     |

---

## 📞 Emergency Numbers Included

- Police: **100**
- Women Helpline: **181**
- Ambulance: **108**
- Fire: **101**
- Childline: **1098**
- National Emergency: **112**
- Cybercrime: **1930**
- NCW: **7827-170-170**
- NALSA Legal Aid: **15100**
- Anti Trafficking: **1800-419-8588**
- 12 State-wise police numbers
- Mental health helplines

---

## ✅ Features (All Without JavaScript)

- 🆘 SOS Alert submission (stored in DB)
- 📋 Incident report with category + auto IPC section
- 🔍 Case tracking by case ID
- ⚖️ 6 awareness articles on Indian laws (seeded automatically)
- 📞 Complete emergency directory
- 👥 User registration and login
- 📊 Admin dashboard with stats
- ✅ Case status update (Pending → Under Review → Resolved)
- 🆘 SOS resolution by admin
- 🔐 Separate admin login system
